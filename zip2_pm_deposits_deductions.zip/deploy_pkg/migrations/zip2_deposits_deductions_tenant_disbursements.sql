-- ============================================================
-- Zip 2 Migration: Deposits on invoices, deductions table,
--                  tenant disbursements, ditch ledger
-- ============================================================
--
-- Run this entire file as a single paste. All schema + backfill
-- runs in one transaction. After code deploys and held-in-trust
-- numbers are sanity-checked on a landlord page, run the
-- separate DROP TABLE pm_ledger; statement as a final cleanup.
--
-- Idempotent: re-running is safe. All DDL uses IF NOT EXISTS;
-- UPDATEs target a specific known id; INSERT uses a SELECT that
-- inserts zero rows if other_deductions was already migrated.
--
-- Tables changed: tenant_invoices (+2 cols),
--                 landlord_disbursements (+1 col)
-- Tables created: landlord_disbursement_deductions,
--                 tenant_disbursements
-- Rows changed: 1 tenant_invoice row (Shavon Jun 2026),
--               1 landlord_disbursements row (Pidatala Jun 2026),
--               +1 landlord_disbursement_deductions row (Commission)
-- ============================================================

BEGIN;

-- 1. Deposit fields on tenant_invoices
ALTER TABLE tenant_invoices
  ADD COLUMN IF NOT EXISTS deposit_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS deposit_description text;

-- 2. Deposit field on landlord_disbursements - tracks "deposit
--    returned to landlord" separately from regular rent
ALTER TABLE landlord_disbursements
  ADD COLUMN IF NOT EXISTS deposit_amount numeric NOT NULL DEFAULT 0;

-- 3. Itemized deductions table - one row per line item
--    (HOA, lawn, repairs, commission, etc.).
--    disbursement_id IS NULL = pending, waiting to be applied
--    to a future disbursement.
--    disbursement_id IS NOT NULL = applied, attached to that
--    disbursement.
CREATE TABLE IF NOT EXISTS landlord_disbursement_deductions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at      timestamptz NOT NULL DEFAULT now(),
  disbursement_id uuid REFERENCES landlord_disbursements(id) ON DELETE CASCADE,
  landlord_id     uuid NOT NULL REFERENCES landlords(id),
  property_id     uuid NOT NULL REFERENCES managed_properties(id),
  label           text NOT NULL,
  description     text,
  amount          numeric NOT NULL,
  incurred_date   date,
  applied_at      timestamptz,
  sort_order      int NOT NULL DEFAULT 0,
  created_by      uuid REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_ldd_property_pending
  ON landlord_disbursement_deductions (property_id)
  WHERE disbursement_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_ldd_disbursement
  ON landlord_disbursement_deductions (disbursement_id);

-- 4. Tenant disbursements - records when a tenant gets refunded
--    (security deposit refunds primarily). Scoped narrow: each
--    row reduces the held-in-trust balance.
CREATE TABLE IF NOT EXISTS tenant_disbursements (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at      timestamptz NOT NULL DEFAULT now(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id),
  landlord_id     uuid NOT NULL REFERENCES landlords(id),
  property_id     uuid NOT NULL REFERENCES managed_properties(id),
  amount          numeric NOT NULL,
  period_month    int NOT NULL CHECK (period_month BETWEEN 1 AND 12),
  period_year     int NOT NULL CHECK (period_year BETWEEN 2020 AND 2100),
  payment_status  text NOT NULL DEFAULT 'pending',
  payment_date    date,
  notes           text
);
CREATE INDEX IF NOT EXISTS idx_tenant_disbursements_landlord_period
  ON tenant_disbursements (landlord_id, period_year, period_month);

-- 5. Backfill: Shavon Wilson's $2,250 deposit lives on her
--    June 2026 invoice, not in the soon-to-die pm_ledger.
--    Her paid_amount goes from 2250 to 4500 because she
--    actually paid rent + deposit ($4,500 total).
UPDATE tenant_invoices
SET deposit_amount      = 2250,
    deposit_description = 'Security deposit',
    total_amount        = 4500,
    paid_amount         = 4500
WHERE id = 'b5b04d33-d329-4f30-b6b6-08cd687e6cd5';

-- 6. Backfill: Pidatala June $1,000 commission moves from
--    the soon-to-be-deprecated other_deductions field into
--    the new line-item table. Uses SELECT-INSERT so this is
--    safe to re-run (zero rows if already migrated).
INSERT INTO landlord_disbursement_deductions
  (disbursement_id, landlord_id, property_id, label, amount, applied_at, sort_order)
SELECT id, landlord_id, property_id, 'Commission', other_deductions, now(), 0
FROM landlord_disbursements
WHERE id = '575919f0-1edb-43fb-a80c-42f623feb4b8'
  AND other_deductions > 0;

-- 7. Clear the now-migrated legacy field
UPDATE landlord_disbursements
SET other_deductions = 0,
    other_deductions_description = NULL
WHERE id = '575919f0-1edb-43fb-a80c-42f623feb4b8';

COMMIT;

-- 8. Verification - all three rows should show ok = true
SELECT 'Shavon June invoice' AS check_name,
       deposit_amount, total_amount, paid_amount,
       (deposit_amount = 2250 AND total_amount = 4500 AND paid_amount = 4500) AS ok
FROM tenant_invoices
WHERE id = 'b5b04d33-d329-4f30-b6b6-08cd687e6cd5'
UNION ALL
SELECT 'Pidatala June deduction row',
       amount, NULL, NULL,
       (amount = 1000)
FROM landlord_disbursement_deductions
WHERE disbursement_id = '575919f0-1edb-43fb-a80c-42f623feb4b8'
UNION ALL
SELECT 'Pidatala June other_deductions cleared',
       other_deductions, NULL, NULL,
       (other_deductions = 0)
FROM landlord_disbursements
WHERE id = '575919f0-1edb-43fb-a80c-42f623feb4b8';
