#!/bin/bash
# Deploys the Payouts Report fix:
#   The API now also returns:
#     - pm_fees: pending PM agent referral fees (payee_type = 'agent')
#     - landlord_payouts: pending landlord disbursements
#   These populate the existing "PM Referral Fees" and "Landlord Disbursements"
#   sections on /admin/reports/payouts (which were always empty before),
#   and feed into the bank reconciliation totals at the top of the page.

set -e

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_ROOT="${REPO_ROOT}"

cp "${PATCH_ROOT}/app/api/admin/payouts-report/route.ts" \
   "${REPO_ROOT}/app/api/admin/payouts-report/route.ts"

echo "Payouts Report fix deployed."
echo "  - app/api/admin/payouts-report/route.ts"
echo ""
echo "Next: git add -A && git commit -m 'Fix Payouts Report: populate PM and landlord pending sections' && git push"
