import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

// Check if current user has PM admin access
export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ isAdmin: false })
    }

    // Check if user has PM management permission
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('can_manage_pm')
      .eq('id', user.id)
      .single()

    if (userError || !userData) {
      return NextResponse.json({ isAdmin: false })
    }

    return NextResponse.json({ 
      isAdmin: userData.can_manage_pm === true,
      userId: user.id
    })
  } catch (error: any) {
    console.error('Admin check error:', error)
    return NextResponse.json({ isAdmin: false, error: error.message })
  }
}
