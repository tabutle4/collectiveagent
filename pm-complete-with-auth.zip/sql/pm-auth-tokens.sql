-- PM Passwordless Auth Tokens
-- Run this in Supabase SQL Editor

CREATE TABLE public.pm_auth_tokens (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  
  -- Who is this for
  user_type text NOT NULL CHECK (user_type IN ('landlord', 'tenant')),
  user_id uuid NOT NULL,
  email text NOT NULL,
  
  -- Token (64 hex chars = 256 bits)
  token text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  
  -- Expiry and usage
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '15 minutes'),
  used_at timestamptz,
  
  -- Security metadata
  ip_address text,
  user_agent text
);

-- Index for token lookup (most common query)
CREATE INDEX idx_pm_auth_tokens_token ON public.pm_auth_tokens(token);

-- Index for cleanup of expired tokens
CREATE INDEX idx_pm_auth_tokens_expires ON public.pm_auth_tokens(expires_at);

-- Cleanup function to remove old tokens (run periodically)
CREATE OR REPLACE FUNCTION cleanup_pm_auth_tokens()
RETURNS void AS $$
BEGIN
  DELETE FROM public.pm_auth_tokens 
  WHERE expires_at < now() - interval '24 hours';
END;
$$ LANGUAGE plpgsql;

-- PM Sessions table (for tracking active sessions)
CREATE TABLE public.pm_sessions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  
  -- Who
  user_type text NOT NULL CHECK (user_type IN ('landlord', 'tenant')),
  user_id uuid NOT NULL,
  email text NOT NULL,
  
  -- Session token (stored in httpOnly cookie)
  session_token text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  
  -- Expiry
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days'),
  
  -- Security metadata
  ip_address text,
  user_agent text,
  last_accessed_at timestamptz DEFAULT now()
);

CREATE INDEX idx_pm_sessions_token ON public.pm_sessions(session_token);
CREATE INDEX idx_pm_sessions_expires ON public.pm_sessions(expires_at);
CREATE INDEX idx_pm_sessions_user ON public.pm_sessions(user_type, user_id);

-- Access log for audit trail
CREATE TABLE public.pm_access_log (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  
  user_type text NOT NULL,
  user_id uuid NOT NULL,
  email text,
  
  action text NOT NULL, -- 'login_requested', 'login_success', 'logout', 'session_check'
  ip_address text,
  user_agent text
);

CREATE INDEX idx_pm_access_log_user ON public.pm_access_log(user_type, user_id);
CREATE INDEX idx_pm_access_log_created ON public.pm_access_log(created_at);
