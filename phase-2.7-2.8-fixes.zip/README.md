# Phase 2.7 + 2.8 — Referral Agent / Rounding / Side-Commission Reload / %-Based Referral

## TL;DR

This deliverable bundles **two phases**:

- **Phase 2.7** (Fixes 1–9): referral agent flow, brokerage split rounding, side-commission reload, plan-default split, auto-rebalance.
- **Phase 2.8** (Fix 10): percentage-based referral basis — referrals can be entered as `30% of side` and auto-recompute when the side commission changes.

Drop the four `.tsx`/`.ts` files into the repo (paths preserved). Run the SQL migration in `migrations/supabase_migration_tia_basis_input_mode.sql` against Supabase **before** the code deploy. Migration is additive and idempotent.

## Files

| Path | What changed |
|---|---|
| `app/admin/transactions/[id]/page.tsx` | Phase 2.7 Fixes 1, 2, 3, 5a, 7; Phase 2.8 wires `onSaveBasisMode` |
| `components/transactions/AgentCardFinancials.tsx` | Phase 2.7 Fixes 4, 5b, 6; Phase 2.8 BasisModeToggle |
| `app/api/admin/transactions/[id]/route.ts` | Phase 2.7 Fixes 5c, 8, 9; Phase 2.8 `recomputePercentageBasedReferrals` + side-commission hook + server-authoritative basis re-derivation |
| `app/api/admin/transactions/smart-calc/route.ts` | Phase 2.7 Fix 5d |
| `migrations/supabase_migration_tia_basis_input_mode.sql` | **Phase 2.8 DB migration** — adds `basis_input_mode` and `basis_percentage` columns |

`git diff --stat HEAD` against the original tree shows only the four source files. `tsc --noEmit` passes clean.

## Deploy order

**Order matters.** Run in this sequence:

1. **DB migration first.** Paste the contents of `migrations/supabase_migration_tia_basis_input_mode.sql` into Supabase SQL editor and run. It's idempotent (`IF NOT EXISTS`) and additive — purely safe. Verify by running the three post-migration queries in the file.
2. **Code deploy.** Unzip the four source files into the repo, commit on `main`, push. Vercel auto-deploys.

Why the migration first: the FE code reads `basis_input_mode` and `basis_percentage` from row data on the `agent.collectiverealtyco.com` page load. Without the columns, those fields are `undefined` — the FE handles that gracefully (treats as 'amount' mode), but cleaner not to ship code that references columns that don't exist yet.

## Phase 2.7 — what each fix does

### Fix 1 — Skip auto-calc on referral / team_lead / momentum_partner rows
`page.tsx` ~ line 527. Frontend auto-calc effect was running smart-calc on every agent row, including referrals. For referrals, it wrote `agent_gross` and `brokerage_split` against a phantom basis computed from `office_gross`, but never wrote `agent_basis` itself. Setting a split % then saved `agent_gross = $0`. Fix: scope the auto-calc to `primary_agent | listing_agent | co_agent` only.

### Fix 2 — Hide lead-source banner on non-primary rows
`page.tsx` ~ line 2112. The "Who sourced this lead?" picker only drives the primary's split. Scoped to primary roles.

### Fix 3 — Hide momentum partner banner on non-primary rows
`page.tsx` ~ line 2140. The momentum partner payout derives from the primary's commission, so the green banner only belongs on the primary's card.

### Fix 4 — Hide Team Lead row in financial breakdown on linked rows
`AgentCardFinancials.tsx` ~ line 642. A referral / team_lead / momentum_partner doesn't itself produce a team lead payout. Gated on `!isLinkedRow`.

### Fix 5 — Rounding: brokerage_split is the residual of rounded agent_gross
Four sites (`page.tsx` saveOverridableField, `AgentCardFinancials.tsx` cascade, `route.ts` cascadePrimarySplit, `smart-calc/route.ts`).

The bug: `agent_gross` and `brokerage_split` were each rounded independently from `basis × pct`. With basis `$8,609.95` and a 90/10 split, both raw values end in `.5`, both `Math.round` them up, and the sum exceeds basis by $0.01. The `10.000116141995203%` you saw is `861.00 / 8609.95 × 100`.

The fix: round `agent_gross` first, then `brokerage_split = basis − rounded(agent_gross)`. Always sums to basis.

### Fix 6 — Display brokerage % as `100 − splitPct`
`AgentCardFinancials.tsx` ~ line 467. The split_percentage column is the canonical input. Showing `100 − splitPct` gives a clean number regardless of basis precision.

### Fix 7 — Overview side commission edits reload data
`page.tsx` ~ line 680. Now reloads on any of: `monthly_rent`, `lease_term`, `listing_side_commission`, `buying_side_commission`, `gross_commission`, `office_gross`, `transaction_type`, `is_intermediary` — so the server's auto-broadcasts show without manual refresh.

### Fix 8 — Referral agent inherits the agent's commission plan default split
New helper `resolveAgentPlanSplit` + branch in `add_internal_agent`. New referral_agent rows are stamped with the agent's plan default split (handling lease vs sales) using the same fuzzy-match logic as `cascadePrimarySplit`. Row arrives at e.g. 90/10 instead of blank.

### Fix 9 — Auto-rebalance: referral basis ↔ same-side primary basis
New helper `rebalanceReferralCarveouts` + triggers in `update_internal_agent`, `delete_internal_agent`, `delete_internal_agent_cascade`. When a referral agent's `agent_basis` is set, edited, or removed, the same-side primary's `agent_basis` adjusts so the two pools sum to the side commission. Same-side primary preference: `primary_agent` → `listing_agent` → `co_agent`. Idempotent and skips paid / closed.

## Phase 2.8 — percentage-based referral basis

### What it does

On a referral_agent row, the admin now sees a small `$ | %` toggle above the Agent Basis field. The dollar entry path is unchanged (default mode for all existing rows). The new percentage entry path lets you type "20" and have the row pin itself to 20% of the side commission — and when the side commission later changes, the dollars auto-recompute.

### How it works end-to-end

**Storage** — two new columns on `transaction_internal_agents`:

- `basis_input_mode text DEFAULT 'amount'` — `'amount'` or `'percentage'`.
- `basis_percentage numeric(5,2)` — null in 'amount' mode, otherwise the chosen %.

`agent_basis` remains the dollar source of truth used by every downstream report (statements, 1099, dashboards). The percentage columns are bookkeeping for the recompute trigger.

**FE — BasisModeToggle component** (AgentCardFinancials.tsx ~ line 342):

- Renders only on `referral_agent` rows.
- Initial mode reads from `agent.basis_input_mode`.
- `$` button → save `{ basis_input_mode: 'amount', basis_percentage: null }`. Existing dollar `agent_basis` stays where it is.
- `%` button → derive the % from current `agent_basis ÷ side_commission` as a starting value (so the dollars carry over). Save `{ basis_input_mode: 'percentage', basis_percentage: <derived> }`.
- In `%` mode, an inline input lets the admin type a percentage; commits on Enter or blur. Shows the resulting dollar amount as `= $X,XXX.XX` next to the field.
- Disabled with a tooltip if side commission isn't set yet.

**BE — server-authoritative recompute** in `update_internal_agent`:

- When the FE sends `basis_input_mode='percentage' + basis_percentage`, the server fetches the current side commission (NOT trusting the FE's cached value), then computes `agent_basis = round(side_comm × pct / 100)` and re-stamps `agent_gross`, `brokerage_split`, `agent_net`, `amount_1099_reportable`. Round-gross-first rule applies.
- When mode flips to `'amount'`, server clears `basis_percentage` so the column reflects the source of truth.
- After saving, the existing Fix 9 rebalance fires — same-side primary adjusts to whatever the new referral basis turned out to be.

**BE — side-commission propagation** in `update_transaction`:

- After saving any change to `listing_side_commission` or `buying_side_commission` (including changes driven by `gross_commission` / `office_gross` / `sales_price` auto-broadcasts), the route re-fetches the now-saved side commissions and calls a new helper `recomputePercentageBasedReferrals(transactionId, side, newSideCommission)` for each side.
- The helper iterates referral_agent rows on the side with `basis_input_mode='percentage'`, recomputes their dollars from the new commission, and updates `agent_basis`, `agent_gross`, `brokerage_split`, `agent_net`, `amount_1099_reportable`.
- Paid rows are skipped (locked).
- After the referral rows update, `rebalanceReferralCarveouts(transactionId, side)` adjusts the same-side primary.

### Concrete example

```
Buying side commission: $5,000

1. Add primary agent (buyer side)
   → cascade fires
   → primary basis = $5,000

2. Add referral agent (buyer side)
   → row arrives with split_percentage = 90 from plan default (Fix 8)
   → basis_input_mode = 'amount', basis_percentage = null (default)

3. Click % on the referral row's toggle
   → row saves { basis_input_mode: 'percentage', basis_percentage: 0 }
   → toggle UI now shows a % input

4. Type 20 in the % field, Enter
   → FE sends { basis_input_mode: 'percentage', basis_percentage: 20 }
   → BE fetches side commission ($5,000), computes:
       agent_basis  = round(5000 × 20 / 100) = $1,000
       agent_gross  = round(1000 × 90 / 100) = $900
       brokerage    = 1000 - 900            = $100
   → Saves all four. Rebalance fires.
   → Primary's basis adjusts to $5,000 − $1,000 = $4,000
   → Primary's cascade re-stamps gross/brokerage from $4,000.

5. LATER: someone changes buying_side_commission to $6,000 on overview.
   → update_transaction saves the new commission.
   → recomputePercentageBasedReferrals fires for buyer side:
       new agent_basis = round(6000 × 20 / 100) = $1,200
       new agent_gross = round(1200 × 90 / 100) = $1,080
       new brokerage   = 1200 - 1080            = $120
   → Rebalance fires: primary's basis adjusts to $6,000 − $1,200 = $4,800.

6. Reload the page. Both rows show the new dollar values. No manual nudge.
```

### Edge cases handled

- **Side commission is 0 or not yet set.** The toggle's `%` button is disabled with a tooltip. If somehow data is in this state, the BE recompute helper no-ops.
- **Paid rows.** The recompute helper skips `payment_status='paid'`. Editing locked fields on a paid row still produces the existing 409.
- **Closed transactions.** Rebalance and recompute both check `txn.status === 'closed'` and skip.
- **Mode flip with no save.** Toggle is ephemeral until a save commits. Mode in DB doesn't change. On page reload, mode comes from DB.
- **No referrals on a side.** Recompute helper returns 0 updated; rebalance no-ops because there's nothing to redistribute.
- **Multiple referrals on the same side.** All %-based ones get recomputed; their summed basis subtracts from the same-side primary. Mixed amount + percentage referrals on the same side are fine — only the %-based ones recompute.
- **Decimal percentages.** `numeric(5,2)` allows 0.00–999.99 (range capped to 0–100 by FE). 12.5%, 33.33%, etc. all work.

## What was deliberately NOT changed

- **`recomputeOfficeNet`** unchanged. Referrals have a real `brokerage_split` so the row is already counted.
- **BTSA / Rebate visibility on referral rows** still hidden via `isLinkedRow`. Those are contract-side adjustments and don't apply to referral fees.
- **Existing rows.** All pre-existing referral rows default to `basis_input_mode='amount'` and `basis_percentage=null`. No behavior change unless admin explicitly toggles to `%`.

## Suggested commit message

```
fix(transactions): referral agent flow, rounding, side-commission reload,
                   plan-default split, auto-rebalance, %-based basis

Phase 2.7 — UI / state:
- Skip auto-calc on referral/team_lead/momentum_partner rows.
- Hide lead-source / momentum partner banners on non-primary rows.
- Hide Team Lead financial-breakdown row on linked rows.
- Display brokerage % as 100 - splitPct.
- Reload transaction data after side-commission / gross-commission edits.

Phase 2.7 — math:
- Round agent_gross first, derive brokerage_split as residual. Fixes
  $0.01 over-allocation and 10.000116% display. Applied at four sites.

Phase 2.7 — referral agent workflow:
- New referral_agent rows inherit the agent's commission plan default
  split via resolveAgentPlanSplit (mirrors cascade plan lookup).
- New rebalanceReferralCarveouts helper: when a referral_agent's
  agent_basis is set, edited, or deleted, the same-side primary's
  agent_basis is auto-adjusted to (side_commission - sum of same-side
  referral basis) and the primary re-cascades.

Phase 2.8 — %-based referral basis:
- Migration: add basis_input_mode (text, default 'amount') and
  basis_percentage (numeric) to transaction_internal_agents.
- New BasisModeToggle on referral_agent rows lets admin enter the
  carve-out as $ amount or % of side commission.
- Server-authoritative re-derivation on update_internal_agent when
  mode='percentage'.
- update_transaction calls new recomputePercentageBasedReferrals on
  side-commission changes (direct or via auto-broadcast), then
  rebalanceReferralCarveouts adjusts the same-side primary.
```
